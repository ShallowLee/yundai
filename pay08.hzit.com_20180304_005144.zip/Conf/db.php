<?php
return array(
    'DB_TYPE'               => 'mysql',     // 数据库类型
	'DB_HOST'               => '127.0.0.1', // 服务器地址
	'DB_NAME'               => 'pay08',     // 数据库名
	'DB_USER'               => 'pay08',     // 用户名
	'DB_PWD'                => 'fnXj5yxeCS',   // 密码
	'DB_PORT'               => '3306',      // 端口
    'DB_PREFIX'             => 'pay_',      // 数据库表前缀
);
?>