<?php 
		return array(
			'WEB_URL' => 'pay08.hzit.com',
			'WEB_URL_CZ' => 'pay08.hzit.com',
			'WEB_APIURL' => 'pay08.hzit.com',
			'WEB_NAME'   => '云代付',
			'ADMIN_NAME'  => 'admin',
			'WEB_TEL'  => '4000250520',
			'WEB_COMPANY'  => '杭州云代科技有限公司',
			'WEB_ICP'  => '浙ICP备14037779号' 
			
		);
?>