<?php
   //开启调试模式
  define('APP_DEBUG',true);
   
   //加载框架入口文件
   require "ThinkPHP/ThinkPHP.php";
?>