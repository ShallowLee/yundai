<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=GBK">
<title>财付通分账应用示例11</title>
</head>
<body>
<div align="left">
	页面跳转调用：<br/>
	<a href="./payRequest.php">支付请求</a><br/>
    
    
    <a href="./payRequestcode.php">saoMA支付请求</a><br/>

	<br/>
	后台调用：<br/>
	<a href="./clientQueryTrans.php">订单查询</a><br/>
	<a href="./clientRefund.php">退款(带证书后台https）</a><br/>
	<a href="./clientQueryRefund.php">退款查询</a><br/>
	<a href="./clientCheck.php">对账单下载</a><br/>

</div>
</body>
</html>
