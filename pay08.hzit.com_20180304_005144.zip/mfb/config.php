﻿<?php
define("MERCHNO", "611200000100210");//钱包商户号
define("KEY", "5c25b3cd");//钱包密钥
