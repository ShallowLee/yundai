<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>请不要非法访问</title>
<script type="text/javascript" defer="defer">
function tz(){
	location.href="http://<?php echo C("WEB_URL");?>/";
}

window.setTimeout("tz()",100);	
</script>
</head>
</html>