//
//  LLViewController.h
//  DemoWap
//
//  Created by xuyf on 14-6-3.
//  Copyright (c) 2014年 llyt. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LLViewController : UIViewController <UIWebViewDelegate>
@property (weak, nonatomic) IBOutlet UIWebView *webview;

@end
