//
//  LLViewController.m
//  DemoWap
//
//  Created by xuyf on 14-6-3.
//  Copyright (c) 2014年 llyt. All rights reserved.
//

#import "LLViewController.h"

@interface LLViewController ()

@property (nonatomic, assign) int pageIndex;

@end

@implementation LLViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    NSString *urlString = @"https://yintong.com.cn/llpayh5/test.jsp";
    NSURLRequest *urlReq = [NSURLRequest requestWithURL:[NSURL URLWithString:urlString]];
    [self.webview loadRequest:urlReq];
    
    self.webview.frame = self.view.bounds;
    
    self.webview.delegate = self;
    
    self.pageIndex = 0;
    
    //[self loadWebView];
}

- (void)viewDidAppear:(BOOL)animated{
    
    self.webview.frame = self.view.bounds;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    if (self.pageIndex == 0){
        self.pageIndex ++;
        //document.getElementByName('inputForm')[0]
        //NSLog(@"123");
        NSLog(@"%@", [webView stringByEvaluatingJavaScriptFromString:@"document.getElementsByName('inputForm')[0].submit();"]);
    }
}

@end
