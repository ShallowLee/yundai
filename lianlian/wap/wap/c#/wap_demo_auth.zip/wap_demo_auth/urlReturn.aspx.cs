﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

/// <summary>
/// 功能：支付结束后返回页面
/// </summary>
/// 

public partial class urlReturn : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}